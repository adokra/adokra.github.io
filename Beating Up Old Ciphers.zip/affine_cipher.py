original_letters = 'abcdefghijklmnopqrstuvwxyz'
a = 23
b = 12
# Encryption function = (a * x + b) % 26
for i in range(26):
    letter_num = (a * i + b) % 26
    print(chr(ord('a') + i) + ' - ' + chr(ord('a') + letter_num))
# a^-1 is the reciprocal of a or in this case 1 / 23