alphabet_dict = {}
for i in range(26):
    current_letter = ord('a') + i
    alphabet_dict[chr(current_letter)] = 0
substitution_file = open('substitution.txt', 'r')
substitution_text = substitution_file.read()
for letter in substitution_text:
    current_letter = letter.lower()
    if current_letter >= 'a' and current_letter <= 'z':
        alphabet_dict[current_letter] += 1
sorted_alphabet = sorted(alphabet_dict.items(), key=lambda x: x[1], reverse=True)
print(sorted_alphabet)
text_freqs = ''
for letter in sorted_alphabet:
    text_freqs += letter[0]
english_freqs = 'etaoinsrhdlucmfywgpbvkxqjz'
print('Text freqs: ' + text_freqs)
print('English freqs: ' + english_freqs)
solve_freqs = 'ethoanirsdluwgmcfypbkvjxqz'
solve_text = ''
for letter in substitution_text:
    current_letter = letter.lower()
    if current_letter >= 'a' and current_letter <= 'z':
        for i in range(26):
            if text_freqs[i] == current_letter:
                solve_text += solve_freqs[i]
                break
    else:
        solve_text += current_letter
print(solve_text)
"""
I looked for patterns in simple words, and if I thought a different letter would fit better in the simple word, 
I would switch the original letter and the different letter in the solve_freqs string. Repeating this process 
would eventually solve the text.
"""