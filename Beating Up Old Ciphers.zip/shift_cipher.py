shift_file = open('shift.txt', 'r')
shift_text = shift_file.read()
def abs_diff(string, string_shifted):
    temp = 0
    sum = 0
    for index in range(len(string)):
        for index_shifted in range(len(string_shifted)):
            if string[index] == string_shifted[index_shifted]:
                temp = index_shifted
                break
        sum += abs(temp - index)
    return sum
shift_freqs = {}
for rot in range(26):
    alphabet_dict = {}
    for i in range(26):
        current_letter = ord('a') + i
        alphabet_dict[chr(current_letter)] = 0
    for letter in shift_text:
        letter = letter.lower()
        if letter >= 'a' and letter <= 'z':
            current_letter = chr((ord(letter) - ord('a') - rot) % 26 + ord('a'))
            alphabet_dict[current_letter] += 1
    sorted_alphabet = sorted(alphabet_dict.items(), key=lambda x: x[1], reverse=True)
    text_freqs = ''
    for letter in sorted_alphabet:
        text_freqs += letter[0]
    shift_freqs[rot] = text_freqs
min_diff = float('inf')
best_rot = None
english_freqs = 'etaoinsrhdlucmfywgpbvkxqjz'
for rot in range(len(shift_freqs)):
    current_diff = abs_diff(shift_freqs[rot], english_freqs)
    if current_diff < min_diff:
        min_diff = current_diff
        best_rot = rot
solve_text = ''
for letter in shift_text:
    letter = letter.lower()
    if letter >= 'a' and letter <= 'z':
        solve_text += chr((ord(letter) - ord('a') - best_rot) % 26 + ord('a'))
    else:
        solve_text += letter
print(best_rot)
print(solve_text)